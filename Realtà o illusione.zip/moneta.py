# Copyright (C) 2025 Francesco Piroddi
# Questo programma è distribuito sotto la licenza GPL 3.0

import random

def lancia_moneta():
    return random.choice(["Realtà", "Illusione"])

def main():
    input("Premi Invio per lanciare la moneta...")
    risultato = lancia_moneta()
    print(f"Il risultato del lancio è: {risultato}")

if __name__ == "__main__":
    main()
